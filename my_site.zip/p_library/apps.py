from django.apps import AppConfig


class PLibraryConfig(AppConfig):
    name = 'p_library'
